
# Client Onboarding Platform

A Java Spring Boot and Angular-based onboarding system with REST APIs, secure authentication, and real-time document processing.

## Features
- User registration
- Status API
- Frontend onboarding UI (Angular)

## Run Backend
```bash
mvn spring-boot:run
```

## Run Frontend
```bash
npm install
npm start
```
