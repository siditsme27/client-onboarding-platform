
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `<h1>Client Onboarding</h1><p>Welcome to the onboarding portal.</p>`,
})
export class AppComponent {}
